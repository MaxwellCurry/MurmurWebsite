export const firebaseConfig = { //eventually move to config.js file -> temporary for now
  apiKey: "AIzaSyCyqYSgE4lza8qMRAgA4QD_ktre6t9BnQc",
  authDomain: "murmurwebsite.firebaseapp.com",
  projectId: "murmurwebsite",
  storageBucket: "murmurwebsite.appspot.com",
  messagingSenderId: "499595493997",
  appId: "1:499595493997:web:5295c99c3e07d9f7dd7564",
  measurementId: "G-P59KESGR07"
};